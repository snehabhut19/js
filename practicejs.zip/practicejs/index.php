<html>
<head>
    <title> signup form </title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="style.css">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

  <style>
      .error{
          color : red;
      }
      </style>
</head>
<body>
<section class="vh-100 gradient-custom">
  <div class="container py-5 h-100">
    <div class="row justify-content-center align-items-center h-100">
      <div class="col-12 col-lg-9 col-xl-7">
        <div class="card shadow-2-strong card-registration" style="border-radius: 15px;">
          <div class="card-body p-4 p-md-5">
            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5">Registration Form</h3>
            <form  name="reg" action=""  id="frm" method="post" class="form" enctype="multipart/form-data">
              <div class="row">
                <div class="col-md-6 mb-4">
                  <div class="form-outline">
                  <label class="form-label" for="name"> Name</label>
                    <input type="text" id="name" class="form-control form-control-lg check" name="name" >
                    <p id="f" class="error">*please enter the name</p>
                  </div>
                </div>
                <div class="col-md-6 mb-4">
                  <div class="form-outline">
                  <label class="form-label" for="email">email</label>
                    <input type="text" id="email" class="form-control form-control-lg check"  name="email"/>
                     <p id="e" class="error">**please enter email</p>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6 mb-4 d-flex align-items-center">
                  <div class="form-outline datepicker w-100">
                  <label for="password" class="form-label">password</label>
                    <input
                      type="password"
                      class="form-control form-control-lg check"
                      id="password"
                      name="password"
                      oninput="undisablePsw()"
                    />
                    <p id="p" class="error">*please enter the password</p>
                  </div>

                  <!-- <div class="col-md-6 mb-4 d-flex align-items-center"> -->
                  <div class="form-outline datepicker w-100" >
                  <label for="password" class="form-label">con-pass</label>
                    <input
                      type="password"
                      class="form-control form-control-lg check"
                      id="conpass"
                      name="conpass"
                    />
                    <p id="cp" class="error">*please enter the con-pass</p>
                  </div>
                </div>
                <div class="col-md-6 mb-4">
                  <h6 class="mb-2 pb-1">Gender: </h6>
                  <div class="form-check form-check-inline">
                    <input
                      class=" form-control form-check-input check"
                      type="radio"
                      name="gender"
                      id="gender"
                      value="female"
                      checked
                    />
                    <label class="form-check-label check" for="female">female</label>
                  </div>

                  <div class="form-check form-check-inline">
                    <input
                      class="form-control form-check-input check"
                      type="radio"
                      name="gender"
                      id="gender"
                      value="male"
                    />
                    <label class="form-check-label check" for="gender">male</label>
                  </div>
                  <div class="form-check form-check-inline">
                    <input
                      class="form-control form-check-input check"
                      type="radio"
                      name="gender"
                      id="gender"
                      value="other"
                    />
                    <label class="form-check-label check" for="other">other</label>
                    <p id="g" class="error">*please enter the gender</p>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6 mb-4 pb-2">
                  <div class="form-outline">
                  <label class="form-label" for="phone">phone number</label>
                    <input type="number" id="phone" class="form-control form-control-lg phone-input check" name="phone" />
                   <p id="ph" class="error">*please enter the phone number</p>
                  </div>
                </div>
                <div class="col-md-6 mb-4 pb-2">
                  <div class="form-outline">
                  <label>ADDRESS :</label>
                    <textarea name="address" id="address" class="form-control check"></textarea>
                    <p id="a" class="error">*please enter the address</p>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-12">
                <label>CITY : </label>
                    <select id="city" name="city" class="form-control check">
                    <option  value="">select city</option>
                    <option value="rajkot">rajkot</option>
                    <option value="ahmedabad">ahmedabad</option>
                    <option value="surat"> surat</option>
                    </select>
                    <p id="ci" class="error">*please enter the city</p>
                </div>
              </div>
              <br>
              <div class="row">
                <div class="col">
                    <label>HOBBIES :</label>
                    <input type="checkbox" id="hobbies1" name="hobbies[]" value="reading" class="check hb">reading
                    <input type="checkbox" id="hobbies2" name="hobbies[]" value="writting" class="check hb">writting
                    <p id="h" class="error">*please enter the hobbies</p>
                </div>
                <div class="col">
                    <label>FILE :</label>
                    <input type="file" id="file" name="file" class="form-control check">
                    <p id="fi" class="error">*please enter the file</p>
                </div>
            </div>
            <br>
            <div>
            <div>
                <input type="checkbox" name="checkbox" id="checkbox">email me
                </div>
              <div class="mt-4 pt-2">
                <input class="btn btn-primary btn-lg" type="submit" value="Submit" id="submit" name="submit"/>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- js link -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

</script>
<script src="js/valid.js"></script>
</body>
</html>
