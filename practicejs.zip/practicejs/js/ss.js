(function($) {
    var phone1 =  /^\d{10}$/;
    $("#frm").submit(function( event ) {
        var flag = 1;
        var check = $(this).find('.check');
        check.each(function(value) {
            if(!$(this).val() && $(this).attr('type') != 'checkbox') {
                $(this).parent().find('.error').addClass('inputerror');
                flag = 0;
            }
        });

        if(!$(this).find('#hobbies1').prop("checked") && !$(this).find('#hobbies1').prop("checked")) {
            $('#h').addClass('inputerror');
            flag = 0;
        }
        if (!flag) {
            return false;
        }
        return true;
        
    });

    $('#email').on('keydown', function() {
        var re = new RegExp();
        re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
        var sinput;
        sinput = "";
        sinput = $('#email').val();
        if (!re.test(sinput)) {
            fields = '1';
            $('#e').addClass('inputerror');
        } else {

            $('#e').removeClass('inputerror');
        }
    });
    $('#password').keyup(function() {
        validatePassword();
    });

    function validatePassword() {
        let passwordValue =
            $('#password').val();
        if ((passwordValue.length < 3) ||
            (passwordValue.length > 10)) {
            $('#p').addClass('inputerror');
            $('#p').html("**length of your password must be between 3 and 10");
            $('#p').css("color", "red");
            passwordError = false;
            return false;
        } else {
            $('#p').removeClass('inputerror');
        }
    }

    $('#conpass').keyup(function() {
        validateConfirmPassword();
    });

    function validateConfirmPassword() {
        let confirmPasswordValue =
            $('#conpass').val();
        if (confirmPasswordValue.length == '') {
            $('#cp').addClass('inputerror');
            confirmPasswordError = false;
            return false;
        }
        let passwordValue =
            $('#password').val();
        if (passwordValue != confirmPasswordValue) {
            $('#cp').addClass('inputerror');
            $('#cp').html(
                "**Password didn't Match");
            $('#cp').css(
                "color", "red");
            confirmPasswordError = false;
            return false;
        } else {
            $('#cp').removeClass('inputerror');
        }
    }
$('#city').on('change', function () { 
    var city = $(this).val();
    var _grandParent = $( this ).parents();
    if (city) {
        $('#ci').removeClass('inputerror'); 
    }else{
        $('#ci').addClass('inputerror');
        fields = '1';
    }
});
$( '#file' ).on( 'keydown', function () { 
    var _grandParent = $( this ).parents();
if (file == "" || file == null) {
    fields = '1';
    $('#fi').addClass('inputerror');
    }
    else{
        $('#fi').removeClass('inputerror');
    }
});
$('#hobbies1, #hobbies2').click(function () {

    if ($('#hobbies2').is(':checked') || $('#hobbies1').is(':checked')) {
        $('#h').removeClass('inputerror');
    } else {
        fields = '1';
        $('#h').addClass('inputerror');
    }
});
    $(document).on('change', '.check', function () {
       
        var answer = $(this).val();
        // console.log( $(this).parent());
        if (answer == "" ) {
            $(this).parent().find('.error').show();
            }else{
                $(this).parent().find('.error').removeClass('inputerror');
            } 
    });
    $( '#phone' ).on( 'keydown', function () { 
        var _grandParent = $( this ).parents();
        if(phone1.test(phone) == 0){
        $('#ph').addClass('inputerror');
            $('#ph').html(
                "only numbers are alowed");
            $('#ph').css(
                "color", "red");
        }
        else{
            $('#ph').removeClass('inputerror'); 
        }
    });


})(jQuery);
