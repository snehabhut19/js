
( function( $ ) {


// valid name

$('#f').hide();
let usernameError = true;
$('#name').keyup(function () {
    validateUsername();
});
function validateUsername() {
    let usernameValue = $('#name').val();
    if (usernameValue.length == '') {
    $('#f').show();
        usernameError = false;
        return false;
    }
    else if((usernameValue.length < 3)||
            (usernameValue.length > 10)) {
        $('#f').show();
        $('#f').html
        ("**length of username must be between 3 and 10");
        usernameError = false;
        return false;
    }else if (usernameValue.length == '') {
        $('#f').show();
       
            usernameError = false;
            return false;
        }
    else {
        $('#f').hide();
    }
  }

// Validate Password
$('#p').hide();
let passwordError = true;
$('#password').keyup(function () {
    validatePassword();
});
function validatePassword() {
    let passwordValue =
        $('#password').val();
    if (passwordValue.length == '') {
        $('#p').show();
        passwordError = false;
        return false;
    }
    if ((passwordValue.length < 3)||
        (passwordValue.length > 10)) {
        $('#p').show();
        $('#p').html
("**length of your password must be between 3 and 10");
        $('#p').css("color", "red");
        passwordError = false;
        return false;
    } else {
        $('#p').hide();
    }
}
// Validate Confirm Password
$('#cp').hide();
let confirmPasswordError = true;
$('#conpass').keyup(function () {
    validateConfirmPassword();
});
function validateConfirmPassword() {
    let confirmPasswordValue =
        $('#conpass').val();
        if (confirmPasswordValue.length == '') {
            $('#cp').show();
            confirmPasswordError = false;
            return false;
        }
    let passwordValue =
        $('#password').val();
    if (passwordValue != confirmPasswordValue) {
        $('#cp').show();
        $('#cp').html(
            "**Password didn't Match");
        $('#cp').css(
            "color", "red");
        confirmPasswordError = false;
        return false;
    } else {
        $('#cp').hide();
    }
}

// Submit button
    $('#submit').click(function () {
        validateUsername();
        validatePassword();
        validateConfirmPassword();
      
        if ((usernameError == true) &&
            (passwordError == true) &&
            (confirmPasswordError == true)
           ) {
            return true;
        } else {
            return false;
        }
    });




})( jQuery );