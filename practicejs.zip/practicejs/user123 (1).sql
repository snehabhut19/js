-- phpMyAdmin SQL Dump
-- version 4.9.5deb2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 15, 2022 at 09:14 AM
-- Server version: 8.0.28-0ubuntu0.20.04.3
-- PHP Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user`
--

-- --------------------------------------------------------

--
-- Table structure for table `user123`
--

CREATE TABLE `user123` (
  `Id` int NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `hobbies` varchar(50) NOT NULL,
  `file` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user123`
--

INSERT INTO `user123` (`Id`, `name`, `email`, `password`, `gender`, `phone`, `address`, `city`, `hobbies`, `file`) VALUES
(27, 'sneha', 'snehabhut19@gmail.com', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'female', '564136', '   egte4r', 'ahmedabad', 'reading', 'photo.jpeg'),
(28, 'sneha', 'snehabhut19@gmail.com', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'female', '564136', '  gfdg', 'ahmedabad', 'readingwritting', 'photo.jpeg'),
(30, 'sneha', 'snehabhut19@gmail.com', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'male', '123456', ' zscs', 'rajkot', 'reading', 'image.jpeg'),
(31, 'sneha', 'snehabhut19@gmail.com', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'female', '564136', '  gfdg', 'ahmedabad', 'reading,writting', 'image.jpeg'),
(32, 'sneha', 'snehabhut19@gmail.com', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'female', '56413', '  gfdg', 'ahmedabad', 'writting', 'image.jpeg'),
(33, 'Test', 'snehabhut19@gmail.com', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'female', '564136', '   aaa', 'surat', 'readingwritting', 'photo.jpeg'),
(34, 'sneha', 'snehabhut19@gmail.com', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'female', '1232132132', ' aa', 'rajkot', 'reading', 'image.jpeg'),
(35, 'aqys', 'snehabhut19@gmail.com', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'female', '1232132132', 'aa ', 'rajkot', 'reading', 'image.jpeg'),
(36, 'aqys', 'snehabhut19@gmail.com', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'female', '1232132132', ' aa ', 'ahmedabad', 'reading', 'image.jpeg'),
(38, 'sneha', 'snehabhut19@gmail.com', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'female', '564136', ' aaa', 'ahmedabad', 'reading,writting', 'photo2.jpg'),
(39, 'sneha', 'snehabhut19@gmail.com', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'female', '564136', ' aa', 'rajkot', 'reading,writting', 'childsandal.jpg'),
(40, 'sadd', 'snehabhut19@gmail.com', '5d793fc5b00a2348c3fb9ab59e5ca98a', 'female', '564136', ' aa', 'rajkot', 'writting', 'childsandal.jpg'),
(41, 'sneha', 'snehabhut19@gmail.com', '0b4e7a0e5fe84ad35fb5f95b9ceeac79', 'female', '564136', ' aaa', 'ahmedabad', 'writting', 'childsandal.jpg'),
(42, 'sneha', 'snehabhut19@gmail.com', 'c1f68ec06b490b3ecb4066b1b13a9ee9', 'female', '1232132132', 'cc', 'rajkot', 'reading,writting', 'childsandal.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user123`
--
ALTER TABLE `user123`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user123`
--
ALTER TABLE `user123`
  MODIFY `Id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
